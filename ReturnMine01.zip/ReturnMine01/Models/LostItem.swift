import Foundation
import FirebaseFirestore

struct LostItem: Codable {
    var id: String?  // Firestore document ID
    var imageUrl: String?
    var title: String
    var subtitle: String
    var location: String
    var date: String
    var reward: String
    var notes: String
    
    init(id: String? = nil, imageUrl: String? = nil, title: String, subtitle: String, location: String, date: String, reward: String, notes: String) {
        self.id = id
        self.imageUrl = imageUrl
        self.title = title
        self.subtitle = subtitle
        self.location = location
        self.date = date
        self.reward = reward
        self.notes = notes
    }
    
    init?(document: DocumentSnapshot) {
        guard let data = document.data() else { return nil }
        self.id = document.documentID
        self.imageUrl = data["imageUrl"] as? String
        self.title = data["title"] as? String ?? ""
        self.subtitle = data["subtitle"] as? String ?? ""
        self.location = data["location"] as? String ?? ""
        self.date = data["date"] as? String ?? ""
        self.reward = data["reward"] as? String ?? ""
        self.notes = data["notes"] as? String ?? ""
    }
    
    func toDictionary() -> [String: Any] {
        return [
            "imageUrl": imageUrl ?? "",
            "title": title,
            "subtitle": subtitle,
            "location": location,
            "date": date,
            "reward": reward,
            "notes": notes
        ]
    }
}
