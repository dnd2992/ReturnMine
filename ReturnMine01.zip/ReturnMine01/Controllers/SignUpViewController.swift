import UIKit

class SignUpViewController: UIViewController {

    let signUpView = SignUpView()

    override func loadView() {
        self.view = signUpView
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 버튼에 액션 연결
        signUpView.submitButton.addTarget(self, action: #selector(didTapSubmit), for: .touchUpInside)
    }
    
    @objc func didTapSubmit() {
        // 회원가입 완료 액션 처리
        dismiss(animated: true, completion: nil) // 예시로 닫기 액션
    }
}
