import UIKit

class EasyLoginViewController: UIViewController {

    let easyLoginView = EasyLogin()

    override func loadView() {
        self.view = easyLoginView
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        easyLoginView.backButton.addTarget(self, action: #selector(didTapBack), for: .touchUpInside)
    }
    
    @objc func didTapBack() {
        self.dismiss(animated: true, completion: nil)
    }
}
