import UIKit
import FirebaseFirestore
import FirebaseStorage

class RegistrationViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, ModalMapViewControllerDelegate {

    let registrationView = RegistrationView()
    var onItemSubmitted: ((LostItem) -> Void)?
    let db = Firestore.firestore()
    let storage = Storage.storage()

    override func loadView() {
        self.view = registrationView
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        registrationView.submitButton.addTarget(self, action: #selector(didTapSubmit), for: .touchUpInside)
        registrationView.backButton.addTarget(self, action: #selector(didTapBack), for: .touchUpInside)
        registrationView.itemPhotoImageView.isUserInteractionEnabled = true
        registrationView.itemPhotoImageView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(didTapImageView)))
        registrationView.mapButton.addTarget(self, action: #selector(didTapMapButton), for: .touchUpInside)
        
        registrationView.itemTextField.delegate = self
        registrationView.brandTextField.delegate = self
        registrationView.locationTextField.delegate = self
        registrationView.rewardTextField.delegate = self
    }

    @objc private func didTapSubmit() {
        // 필수 입력 필드 체크
        guard let image = registrationView.itemPhotoImageView.image, image != UIImage(systemName: "photo") else {
            showAlert(message: "이미지를 선택해주십시오.")
            return
        }

        guard let itemText = registrationView.itemTextField.text, !itemText.isEmpty else {
            showAlert(message: "습득물을 입력해주십시오.")
            return
        }
        guard let brandText = registrationView.brandTextField.text, !brandText.isEmpty else {
            showAlert(message: "색상 및 브랜드를 입력해주십시오.")
            return
        }
        guard let locationText = registrationView.locationTextField.text, !locationText.isEmpty else {
            showAlert(message: "습득 장소를 입력해주십시오.")
            return
        }
        guard let dateText = registrationView.dateTextField.text, !dateText.isEmpty else {
            showAlert(message: "날짜 및 시간을 입력해주십시오.")
            return
        }
        guard let rewardText = registrationView.rewardTextField.text, !rewardText.isEmpty else {
            showAlert(message: "원하는 사례금%를 입력해주십시오.")
            return
        }
        let notesText = registrationView.notesTextField.text ?? ""

        // 사례금 % 입력 검증
        if Double(rewardText) == nil {
            showAlert(message: "숫자를 기입하시오.")
            return
        }

        // 이미지 업로드 및 Firestore에 데이터 저장
        uploadImage(image) { [weak self] imageUrl in
            guard let self = self, let imageUrl = imageUrl else {
                self?.showAlert(message: "업로드에 실패했습니다.")
                return
            }

            let newItem = LostItem(
                imageUrl: imageUrl,
                title: itemText,
                subtitle: brandText,
                location: locationText,
                date: dateText,
                reward: rewardText,
                notes: notesText
            )
            self.saveLostItemToFirestore(newItem)
        }
    }

    private func uploadImage(_ image: UIImage, completion: @escaping (String?) -> Void) {
        guard let imageData = image.jpegData(compressionQuality: 0.8) else {
            completion(nil)
            return
        }

        let imageRef = storage.reference().child("lostItems/\(UUID().uuidString).jpg")
        imageRef.putData(imageData, metadata: nil) { metadata, error in
            if let error = error {
                print("Error uploading image: \(error.localizedDescription)")
                completion(nil)
                return
            }

            imageRef.downloadURL { url, error in
                if let error = error {
                    print("Error getting download URL: \(error.localizedDescription)")
                    completion(nil)
                    return
                }

                completion(url?.absoluteString)
            }
        }
    }

    private func saveLostItemToFirestore(_ item: LostItem) {
        do {
            _ = try db.collection("lostItems").addDocument(from: item, completion: { error in
                if let error = error {
                    print("Error adding document: \(error.localizedDescription)")
                } else {
                    print("Document successfully added")
                    DispatchQueue.main.async {
                        self.dismiss(animated: true, completion: nil)
                    }
                }
            })
        } catch let error {
            print("Error encoding lost item: \(error.localizedDescription)")
        }
    }

    @objc private func didTapMapButton() {
        let mapVC = ModalMapViewController()
        mapVC.modalPresentationStyle = .fullScreen
        mapVC.delegate = self
        present(mapVC, animated: true, completion: nil)
    }

    func didSelectLocation(_ location: String) {
        registrationView.locationTextField.text = location
    }

    private func showAlert(message: String) {
        let alertController = UIAlertController(title: "알림", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "확인", style: .default, handler: nil)
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }

    @objc func didTapBack() {
        dismiss(animated: true, completion: nil)
    }
    
    @objc func didTapImageView() {
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        imagePickerController.sourceType = .photoLibrary
        present(imagePickerController, animated: true, completion: nil)
    }
    
    // UIImagePickerControllerDelegate 메서드
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let selectedImage = info[.originalImage] as? UIImage {
            registrationView.itemPhotoImageView.image = selectedImage
        }
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    // UITextFieldDelegate 메서드
    func textFieldDidEndEditing(_ textField: UITextField) {
        let isValid = !(textField.text?.isEmpty ?? true)
        registrationView.updateStatusView(for: textField, isValid: isValid)
    }

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == registrationView.rewardTextField {
            let allowedCharacters = CharacterSet(charactersIn: "0123456789.")
            let characterSet = CharacterSet(charactersIn: string)
            return allowedCharacters.isSuperset(of: characterSet)
        }
        return true
    }
    
}
