import UIKit

class LostItemDetailViewController: UIViewController {

    var lostItem: LostItem?
    let detailView = LostItemDetailView()

    override func loadView() {
        self.view = detailView
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        if let lostItem = lostItem {
            detailView.configure(with: lostItem)
        }
    }
}
