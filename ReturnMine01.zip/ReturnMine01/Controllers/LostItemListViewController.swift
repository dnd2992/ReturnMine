import UIKit
import FirebaseFirestore

class LostItemListViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    private var lostItems: [LostItem] = []
    private let firebaseDatabaseService = FirebaseDatabaseService()
    private let lostItemListView = LostItemListView()

    override func loadView() {
        view = lostItemListView
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupCollectionView()
        setupBackButton()
        
        firebaseDatabaseService.fetchLostItems { [weak self] items in
            self?.lostItems = items
            self?.lostItemListView.collectionView.reloadData()
        }
    }
    
    private func setupCollectionView() {
        lostItemListView.collectionView.delegate = self
        lostItemListView.collectionView.dataSource = self
        lostItemListView.collectionView.register(LostItemCollectionViewCell.self, forCellWithReuseIdentifier: "LostItemCell")
    }

    private func setupBackButton() {
        // 백버튼 액션 설정
        lostItemListView.backButton.addTarget(self, action: #selector(didTapBackButton), for: .touchUpInside)
    }
    
    @objc private func didTapBackButton() {
        // 현재 화면을 닫음
        self.dismiss(animated: true, completion: nil)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return lostItems.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LostItemCell", for: indexPath) as? LostItemCollectionViewCell else {
            return UICollectionViewCell()
        }
        
        let item = lostItems[indexPath.row]
        cell.titleLabel.text = item.title
        cell.subTitleLabel.text = item.subtitle
        
        if let imageUrl = item.imageUrl, let url = URL(string: imageUrl) {
            DispatchQueue.global().async {
                if let data = try? Data(contentsOf: url), let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        if collectionView.indexPath(for: cell) == indexPath {
                            cell.imageView.image = image
                        }
                    }
                } else {
                    DispatchQueue.main.async {
                        cell.imageView.image = UIImage(systemName: "photo")
                    }
                }
            }
        } else {
            cell.imageView.image = UIImage(systemName: "photo")
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let detailVC = LostItemDetailViewController()
        detailVC.lostItem = lostItems[indexPath.row]
        navigationController?.pushViewController(detailVC, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (view.frame.width / 2) - 15, height: 200)
    }
}
