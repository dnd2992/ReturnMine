import UIKit
import MapKit

protocol ModalMapViewControllerDelegate: AnyObject {
    func didSelectLocation(_ location: String)
}

class ModalMapViewController: UIViewController, UISearchBarDelegate {
    
    let modalMapView = ModalMapView()
    weak var delegate: ModalMapViewControllerDelegate?
    var selectedLocation: String?

    override func loadView() {
        self.view = modalMapView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        modalMapView.backButton.addTarget(self, action: #selector(didTapBack), for: .touchUpInside)
        modalMapView.searchBar.delegate = self
        modalMapView.selectButton.addTarget(self, action: #selector(didTapSelectButton), for: .touchUpInside)
    }
    
    @objc private func didTapBack() {
        dismiss(animated: true, completion: nil)
    }
    
    @objc private func didTapSelectButton() {
        guard let location = selectedLocation else { return }
        delegate?.didSelectLocation(location)
        dismiss(animated: true, completion: nil)
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        
        guard let searchText = searchBar.text, !searchText.isEmpty else { return }
        
        let searchRequest = MKLocalSearch.Request()
        searchRequest.naturalLanguageQuery = searchText
        
        let search = MKLocalSearch(request: searchRequest)
        search.start { [weak self] (response, error) in
            guard let self = self, let response = response else {
                if let error = error {
                    print("Error occurred during search: \(error.localizedDescription)")
                }
                return
            }
            
            if let coordinate = response.mapItems.first?.placemark.coordinate {
                let region = MKCoordinateRegion(center: coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
                self.modalMapView.mapView.setRegion(region, animated: true)
                
                let annotation = MKPointAnnotation()
                annotation.coordinate = coordinate
                annotation.title = searchText
                self.modalMapView.mapView.addAnnotation(annotation)
                
                // 선택된 위치를 저장
                self.selectedLocation = searchText
            }
        }
    }
}
