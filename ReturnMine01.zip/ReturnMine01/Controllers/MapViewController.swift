import UIKit
import MapKit

class MapViewController: UIViewController {
    
    let mapView = MapView()
    
    override func loadView() {
        self.view = mapView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupMapRegion()
        
        // 백버튼에 액션 추가
        mapView.backButton.addTarget(self, action: #selector(didTapBack), for: .touchUpInside)
        mapView.collectionViewButton.addTarget(self, action: #selector(didTapCollectionViewButton), for: .touchUpInside)
    }
    
    private func setupMapRegion() {
        let initialLocation = CLLocation(latitude: 35.1640, longitude: 129.0661)
        let regionRadius: CLLocationDistance = 1000.0
        let coordinateRegion = MKCoordinateRegion(center: initialLocation.coordinate, latitudinalMeters: regionRadius, longitudinalMeters: regionRadius)
        mapView.mapView.setRegion(coordinateRegion, animated: true)
    }
    
    @objc private func didTapBack() {
        dismiss(animated: true, completion: nil)
    }
    
    @objc private func didTapCollectionViewButton() {
        let lostItemListVC = LostItemListViewController()
        lostItemListVC.modalPresentationStyle = .fullScreen
        present(lostItemListVC, animated: true, completion: nil)
    }
}
