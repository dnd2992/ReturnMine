import UIKit

class LoginViewController: UIViewController {
    
    let loginView = LoginView()

    override func loadView() {
        self.view = loginView
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        loginView.quickAuthButton.addTarget(self, action: #selector(didTapQuickAuth), for: .touchUpInside)
        loginView.registerButton.addTarget(self, action: #selector(didTapRegister), for: .touchUpInside)
        loginView.signInButton.addTarget(self, action: #selector(didTapSignIn), for: .touchUpInside)
    }
    
    @objc func didTapQuickAuth() {
        let easyLoginVC = EasyLoginViewController()
        easyLoginVC.modalPresentationStyle = .fullScreen
        present(easyLoginVC, animated: true, completion: nil)
    }
    
    @objc func didTapRegister() {
        let signUpVC = SignUpViewController()
        signUpVC.modalPresentationStyle = .fullScreen
        present(signUpVC, animated: true, completion: nil)
    }
    
    @objc func didTapSignIn() {
        let selectionVC = SelectionViewController()
        selectionVC.modalPresentationStyle = .fullScreen
        present(selectionVC, animated: true, completion: nil)
    }
}
