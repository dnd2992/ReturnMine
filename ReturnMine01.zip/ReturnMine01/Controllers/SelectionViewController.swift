import UIKit

class SelectionViewController: UIViewController {
    
    let selectionView = SelectionView()

    override func loadView() {
        self.view = selectionView
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 버튼에 대한 액션 추가
        selectionView.findLostItemButton.addTarget(self, action: #selector(didTapFindLostItem), for: .touchUpInside)
        selectionView.registerFoundItemButton.addTarget(self, action: #selector(didTapRegisterFoundItem), for: .touchUpInside)
        selectionView.lost112Button.addTarget(self, action: #selector(didTapLost112), for: .touchUpInside)
    }
    
    @objc func didTapFindLostItem() {
        // 분실물 찾기 화면으로 전환
        let mapVC = MapViewController()
        mapVC.modalPresentationStyle = .fullScreen
        present(mapVC, animated: true, completion: nil)
    }
    
    @objc func didTapRegisterFoundItem() {
         // 습득물 등록 화면으로 전환
         let registrationVC = RegistrationViewController()
         registrationVC.modalPresentationStyle = .fullScreen
         present(registrationVC, animated: true, completion: nil)
     }
    
    @objc func didTapLost112() {
        // 로스트 112 웹사이트로 연결
        if let url = URL(string: "https://www.lost112.go.kr/") {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
}
