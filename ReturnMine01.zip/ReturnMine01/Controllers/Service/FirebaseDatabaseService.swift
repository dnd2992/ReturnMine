import FirebaseFirestore

class FirebaseDatabaseService {
    private let db = Firestore.firestore()
    
    func fetchLostItems(completion: @escaping ([LostItem]) -> Void) {
        db.collection("lostItems").getDocuments { snapshot, error in
            if let error = error {
                print("Error fetching documents: \(error.localizedDescription)")
                completion([]) // 에러 발생 시 빈 배열 반환
                return
            }
            
            guard let documents = snapshot?.documents else {
                print("No documents found")
                completion([]) // 문서가 없는 경우 빈 배열 반환
                return
            }
            
            let lostItems = documents.compactMap { document -> LostItem? in
                return LostItem(document: document)
            }
            
            completion(lostItems) // 성공적으로 데이터를 가져왔을 경우 콜백에 데이터 전달
        }
    }
    
    func addLostItem(_ lostItem: LostItem, completion: @escaping (Error?) -> Void) {
        do {
            _ = try db.collection("lostItems").addDocument(from: lostItem) { error in
                if let error = error {
                    print("Error adding document: \(error.localizedDescription)")
                    completion(error)
                } else {
                    print("Document successfully added")
                    completion(nil)
                }
            }
        } catch let error {
            print("Error encoding lost item: \(error.localizedDescription)")
            completion(error)
        }
    }
}
