import UIKit
import SnapKit

class RegistrationView: UIView {

    // UI 요소들 정의
    let backButton: UIButton = {
        let button = UIButton(type: .system)
        let image = UIImage(systemName: "chevron.left")
        button.setImage(image, for: .normal)
        button.tintColor = .black
        return button
    }()

    let titleLabel: UILabel = {
        let label = UILabel()
        label.text = "습득물 등록하기"
        label.font = UIFont.boldSystemFont(ofSize: 27)
        return label
    }()
    
    let itemPhotoImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(named: "uploadImage")
        imageView.contentMode = .scaleAspectFill
        imageView.backgroundColor = .lightGray
        imageView.layer.cornerRadius = 10
        imageView.clipsToBounds = true
        imageView.layer.borderWidth = 1  // 테두리 두께 설정
        imageView.layer.borderColor = UIColor.lightGray.cgColor  // 테두리 색상 설정
        return imageView
    }()
    
    // 필수 입력 필드 왼쪽에 표시할 빨간 점
    func createRequiredIndicator() -> UIView {
        let view = UIView()
        view.backgroundColor = .red
        view.layer.cornerRadius = 4 // 작게 설정
        return view
    }

    var itemRequiredIndicator = UIView()
    var brandRequiredIndicator = UIView()
    var locationRequiredIndicator = UIView()
    var dateRequiredIndicator = UIView()
    var rewardRequiredIndicator = UIView()

    let itemLabel: UILabel = {
        let label = UILabel()
        label.text = "습 득 물"
        return label
    }()
    
    let itemTextField: UITextField = {
        let textField = UITextField()
        textField.borderStyle = .roundedRect
        return textField
    }()
    
    let brandLabel: UILabel = {
        let label = UILabel()
        label.text = "색상 및 브랜드"
        return label
    }()
    
    let brandTextField: UITextField = {
        let textField = UITextField()
        textField.borderStyle = .roundedRect
        return textField
    }()
    
    let locationLabel: UILabel = {
        let label = UILabel()
        label.text = "습득 장소"
        return label
    }()
    
    let locationTextField: UITextField = {
        let textField = UITextField()
        textField.borderStyle = .roundedRect
        return textField
    }()
    
    // 지도 버튼 추가
    let mapButton: UIButton = {
        let button = UIButton(type: .system)
        let image = UIImage(systemName: "map")
        button.setImage(image, for: .normal)
        button.tintColor = .black
        return button
    }()
    
    let dateLabel: UILabel = {
        let label = UILabel()
        label.text = "날짜 및 시간"
        return label
    }()
    
    let dateTextField: UITextField = {
        let textField = UITextField()
        textField.borderStyle = .roundedRect
        return textField
    }()
    
    let rewardLabel: UILabel = {
        let label = UILabel()
        label.text = "사례금 %"
        return label
    }()
    
    let rewardTextField: UITextField = {
        let textField = UITextField()
        textField.borderStyle = .roundedRect
        textField.placeholder = "원하는 사례금 % 를 입력하시오."
        textField.keyboardType = .decimalPad
        return textField
    }()
    
    let notesLabel: UILabel = {
        let label = UILabel()
        label.text = "특이사항"
        return label
    }()
    
    let notesTextField: UITextField = {
        let textField = UITextField()
        textField.borderStyle = .roundedRect
        return textField
    }()
    
    let submitButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("등록하기", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .black
        button.layer.cornerRadius = 5
        return button
    }()
    
    let scrollView = UIScrollView()
    let contentView = UIView()

    let datePicker: UIDatePicker = {
        let picker = UIDatePicker()
        picker.datePickerMode = .dateAndTime
        picker.preferredDatePickerStyle = .wheels
        picker.locale = Locale(identifier: "ko_KR")
        return picker
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
        setupLayout()
        configureDateTextField()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupView() {
        backgroundColor = .white
        
        addSubview(backButton)
        addSubview(titleLabel)
        addSubview(submitButton)
        addSubview(scrollView)
        scrollView.addSubview(contentView)
        
        // 빨간 점 초기화
        itemRequiredIndicator = createRequiredIndicator()
        brandRequiredIndicator = createRequiredIndicator()
        locationRequiredIndicator = createRequiredIndicator()
        dateRequiredIndicator = createRequiredIndicator()
        rewardRequiredIndicator = createRequiredIndicator()
        
        contentView.addSubview(itemPhotoImageView)
        contentView.addSubview(itemRequiredIndicator)
        contentView.addSubview(itemLabel)
        contentView.addSubview(itemTextField)
        contentView.addSubview(brandRequiredIndicator)
        contentView.addSubview(brandLabel)
        contentView.addSubview(brandTextField)
        contentView.addSubview(locationRequiredIndicator)
        contentView.addSubview(locationLabel)
        contentView.addSubview(locationTextField)
        contentView.addSubview(mapButton) // 지도 버튼 추가
        contentView.addSubview(dateRequiredIndicator)
        contentView.addSubview(dateLabel)
        contentView.addSubview(dateTextField)
        contentView.addSubview(rewardRequiredIndicator)
        contentView.addSubview(rewardLabel)
        contentView.addSubview(rewardTextField)
        contentView.addSubview(notesLabel)
        contentView.addSubview(notesTextField)
    }

    private func setupLayout() {
        backButton.snp.makeConstraints { make in
            make.top.equalTo(safeAreaLayoutGuide.snp.top).offset(10)
            make.left.equalToSuperview().offset(20)
        }
        
        titleLabel.snp.makeConstraints { make in
            make.top.equalTo(backButton.snp.bottom).offset(5)
            make.centerX.equalToSuperview()
        }
        
        submitButton.snp.makeConstraints { make in
            make.bottom.equalTo(safeAreaLayoutGuide.snp.bottom).offset(-20)
            make.centerX.equalToSuperview()
            make.height.equalTo(50)
            make.width.equalTo(200)
        }

        scrollView.snp.makeConstraints { make in
            make.top.equalTo(titleLabel.snp.bottom).offset(10)
            make.left.right.equalToSuperview()
            make.bottom.equalTo(submitButton.snp.top).offset(-10)
        }

        contentView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
            make.width.equalToSuperview()
        }
        
        itemPhotoImageView.snp.makeConstraints { make in
            make.top.equalTo(contentView.snp.top).offset(5)
            make.centerX.equalToSuperview()
            make.width.height.equalTo(250)
        }
        
        itemRequiredIndicator.snp.makeConstraints { make in
            make.centerY.equalTo(itemLabel)
            make.left.equalToSuperview().offset(10)
            make.width.height.equalTo(5)  // 크기 조절
        }
        
        itemLabel.snp.makeConstraints { make in
            make.top.equalTo(itemPhotoImageView.snp.bottom).offset(30)
            make.left.equalTo(itemRequiredIndicator.snp.right).offset(5)
            make.width.equalTo(100)
        }
        
        itemTextField.snp.makeConstraints { make in
            make.centerY.equalTo(itemLabel)
            make.left.equalTo(itemLabel.snp.right).offset(10)
            make.right.equalToSuperview().offset(-30)
            make.height.equalTo(40)
        }
        
        brandRequiredIndicator.snp.makeConstraints { make in
            make.centerY.equalTo(brandLabel)
            make.left.equalToSuperview().offset(10)
            make.width.height.equalTo(5)  // 크기 조절
        }
        
        brandLabel.snp.makeConstraints { make in
            make.top.equalTo(itemTextField.snp.bottom).offset(20)
            make.left.equalTo(brandRequiredIndicator.snp.right).offset(5)
            make.width.equalTo(itemLabel)
        }
        
        brandTextField.snp.makeConstraints { make in
            make.centerY.equalTo(brandLabel)
            make.left.equalTo(brandLabel.snp.right).offset(10)
            make.right.equalTo(itemTextField)
            make.height.equalTo(itemTextField)
        }
        
        locationRequiredIndicator.snp.makeConstraints { make in
            make.centerY.equalTo(locationLabel)
            make.left.equalToSuperview().offset(10)
            make.width.height.equalTo(5)  // 크기 조절
        }
        
        locationLabel.snp.makeConstraints { make in
            make.top.equalTo(brandTextField.snp.bottom).offset(20)
            make.left.equalTo(locationRequiredIndicator.snp.right).offset(5)
            make.width.equalTo(itemLabel)
        }
        
        // locationTextField 가로길이를 줄여서 mapButton 추가
        locationTextField.snp.makeConstraints { make in
            make.centerY.equalTo(locationLabel)
            make.left.equalTo(locationLabel.snp.right).offset(10)
            make.right.equalToSuperview().offset(-80) // 여기서 가로 길이를 줄임
            make.height.equalTo(itemTextField)
        }
        
        mapButton.snp.makeConstraints { make in
            make.centerY.equalTo(locationTextField)
            make.left.equalTo(locationTextField.snp.right).offset(10)
            make.width.height.equalTo(30)
            make.right.equalToSuperview().offset(-30)
        }
        
        dateRequiredIndicator.snp.makeConstraints { make in
            make.centerY.equalTo(dateLabel)
            make.left.equalToSuperview().offset(10)
            make.width.height.equalTo(5)  // 크기 조절
        }
        
        dateLabel.snp.makeConstraints { make in
            make.top.equalTo(locationTextField.snp.bottom).offset(20)
            make.left.equalTo(dateRequiredIndicator.snp.right).offset(5)
            make.width.equalTo(itemLabel)
        }
        
        dateTextField.snp.makeConstraints { make in
            make.centerY.equalTo(dateLabel)
            make.left.equalTo(dateLabel.snp.right).offset(10)
            make.right.equalTo(itemTextField)
            make.height.equalTo(itemTextField)
        }
        
        rewardRequiredIndicator.snp.makeConstraints { make in
            make.centerY.equalTo(rewardLabel)
            make.left.equalToSuperview().offset(10)
            make.width.height.equalTo(5)  // 크기 조절
        }
        
        rewardLabel.snp.makeConstraints { make in
            make.top.equalTo(dateTextField.snp.bottom).offset(20)
            make.left.equalTo(rewardRequiredIndicator.snp.right).offset(5)
            make.width.equalTo(itemLabel)
        }
        
        rewardTextField.snp.makeConstraints { make in
            make.centerY.equalTo(rewardLabel)
            make.left.equalTo(rewardLabel.snp.right).offset(10)
            make.right.equalTo(itemTextField)
            make.height.equalTo(itemTextField)
        }
        
        notesLabel.snp.makeConstraints { make in
            make.top.equalTo(rewardTextField.snp.bottom).offset(20)
            make.left.equalTo(itemLabel)
            make.width.equalTo(itemLabel)
        }
        
        notesTextField.snp.makeConstraints { make in
            make.centerY.equalTo(notesLabel)
            make.left.equalTo(notesLabel.snp.right).offset(10)
            make.right.equalTo(itemTextField)
            make.height.equalTo(itemTextField)
            make.bottom.equalTo(contentView.snp.bottom).offset(-20)
        }
    }

    private func configureDateTextField() {
        dateTextField.inputView = datePicker
        
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(donePressed))
        
        toolbar.setItems([flexibleSpace, doneButton], animated: true)
        dateTextField.inputAccessoryView = toolbar
    }

    @objc private func donePressed() {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm"
        dateTextField.text = formatter.string(from: datePicker.date)
        updateStatusView(for: dateTextField, isValid: true)
        self.endEditing(true)
    }
    
    func updateStatusView(for textField: UITextField, isValid: Bool) {
        let indicatorView: UIView?
        switch textField {
        case itemTextField: indicatorView = itemRequiredIndicator
        case brandTextField: indicatorView = brandRequiredIndicator
        case locationTextField: indicatorView = locationRequiredIndicator
        case dateTextField: indicatorView = dateRequiredIndicator
        case rewardTextField: indicatorView = rewardRequiredIndicator
        default: indicatorView = nil
        }
        indicatorView?.backgroundColor = isValid ? .green : .red
    }
}
