import UIKit

class LostItemListView: UIView {

    let searchBar: UISearchBar = {
        let searchBar = UISearchBar()
        searchBar.placeholder = "제품 검색"
        searchBar.searchBarStyle = .minimal
        return searchBar
    }()
    
    let collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 10
        layout.minimumInteritemSpacing = 10
        layout.sectionInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .white
        return collectionView
    }()
    
    let backButton: UIButton = {
        let button = UIButton(type: .system)
        let image = UIImage(systemName: "chevron.left")
        button.setImage(image, for: .normal)
        button.tintColor = .black
        return button
    }()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
        setupLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupView() {
        backgroundColor = .white
        addSubview(searchBar)
        addSubview(collectionView)
        addSubview(backButton)
    }
    
    private func setupLayout() {
        // 백 버튼의 제약 조건 설정
        backButton.snp.makeConstraints { make in
            make.top.equalTo(safeAreaLayoutGuide.snp.top).offset(10)
            make.left.equalToSuperview().offset(20)
            make.width.equalTo(40)
            make.height.equalTo(40)
        }
        
        // 서치바의 제약 조건 설정
        searchBar.snp.makeConstraints { make in
            make.centerY.equalTo(backButton.snp.centerY) // 백버튼과 Y축을 동일하게
            make.left.equalTo(backButton.snp.right).offset(15) // 백버튼에서 30 포인트 떨어진 위치에 배치
            make.right.equalToSuperview().offset(-10)
        }
        
        // 컬렉션 뷰의 제약 조건 설정
        collectionView.snp.makeConstraints { make in
            make.top.equalTo(searchBar.snp.bottom).offset(10)
            make.leading.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
    }

}
