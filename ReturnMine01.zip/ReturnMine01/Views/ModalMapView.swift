import UIKit
import MapKit

class ModalMapView: UIView {
    
    let mapView: MKMapView = {
        let mapView = MKMapView()
        return mapView
    }()
    
    let backButton: UIButton = {
        let button = UIButton(type: .system)
        let image = UIImage(systemName: "chevron.left")
        button.setImage(image, for: .normal)
        button.tintColor = .black
        return button
    }()
    
    let searchBar: UISearchBar = {
        let searchBar = UISearchBar()
        searchBar.placeholder = "위치를 검색하세요"
        return searchBar
    }()
    
    let selectButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("확  인", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = UIColor.black.withAlphaComponent(0.2) // 배경에만 불투명도 적용
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        return button
    }()

    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
        setupLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupView() {
        backgroundColor = .white
        addSubview(mapView)
        addSubview(backButton)
        addSubview(searchBar)
        addSubview(selectButton)
    }
    
    private func setupLayout() {
        backButton.snp.makeConstraints { make in
            make.top.equalTo(safeAreaLayoutGuide.snp.top).offset(10)
            make.left.equalToSuperview().offset(20)
            make.width.height.equalTo(30)
        }
        
        searchBar.snp.makeConstraints { make in
            make.centerY.equalTo(backButton)
            make.left.equalTo(backButton.snp.right).offset(10)
            make.right.equalToSuperview().offset(-20)
        }
        
        mapView.snp.makeConstraints { make in
            make.top.equalTo(searchBar.snp.bottom).offset(10)
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().offset(-60)
        }
        
        selectButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview()
            make.centerX.equalToSuperview()
            make.left.right.equalToSuperview()
            make.height.equalTo(60)
        }
    }
}
