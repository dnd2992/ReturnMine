import UIKit
import MapKit
import SnapKit

class MapView: UIView {

    let mapView: MKMapView = {
        let map = MKMapView()
        map.showsUserLocation = true // 사용자 위치 표시
        return map
    }()
    
    let backButton: UIButton = {
        let button = UIButton(type: .system)
        let image = UIImage(systemName: "chevron.left")
        button.setImage(image, for: .normal)
        button.tintColor = .black
        return button
    }()
    
    let collectionViewButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("이미지로 찾기", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = UIColor.black.withAlphaComponent(0.2) // 배경에만 불투명도 적용
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        return button
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
        setupLayout()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupView() {
        addSubview(mapView)
        addSubview(backButton)
        addSubview(collectionViewButton)
    }

    private func setupLayout() {
        // 맵 뷰의 제약 조건을 Safe Area에 맞게 설정
        mapView.snp.makeConstraints { make in
            make.top.equalTo(safeAreaLayoutGuide.snp.top)
            make.left.equalTo(safeAreaLayoutGuide.snp.left)
            make.right.equalTo(safeAreaLayoutGuide.snp.right)
            make.bottom.equalTo(collectionViewButton.snp.top)
        }
        
        // 백 버튼의 제약 조건 설정
        backButton.snp.makeConstraints { make in
            make.top.equalTo(safeAreaLayoutGuide.snp.top).offset(10)
            make.left.equalToSuperview().offset(20)
            make.width.equalTo(40)
            make.height.equalTo(40)
        }
        
        // 하단 버튼의 제약 조건 설정
        collectionViewButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview()
            make.centerX.equalToSuperview()
            make.left.right.equalToSuperview()
            make.height.equalTo(60)
        }
    }
}
