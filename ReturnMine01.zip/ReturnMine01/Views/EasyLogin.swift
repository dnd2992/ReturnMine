import UIKit
import SnapKit

class EasyLogin: UIView {

    let titleLabel: UILabel = {
        let label = UILabel()
        label.text = "Return\nMine"
        label.numberOfLines = 2
        label.font = UIFont.boldSystemFont(ofSize: 40)
        label.textAlignment = .center
        return label
    }()
    
    let naverButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("네이버 인증", for: .normal)
        button.backgroundColor = UIColor.systemGreen
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 5
        return button
    }()
    
    let kakaoButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("카카오 인증", for: .normal)
        button.backgroundColor = UIColor.systemYellow
        button.setTitleColor(.black, for: .normal)
        button.layer.cornerRadius = 5
        return button
    }()
    
    let publicAuthButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("공인인증서 인증", for: .normal)
        button.backgroundColor = UIColor.systemBlue
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 5
        return button
    }()
    
    let backButton: UIButton = {
        let button = UIButton(type: .system)
        let image = UIImage(systemName: "chevron.left")
        button.setImage(image, for: .normal)
        button.tintColor = .black
        return button
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupView() {
        backgroundColor = .white
        
        addSubview(titleLabel)
        addSubview(naverButton)
        addSubview(kakaoButton)
        addSubview(publicAuthButton)
        addSubview(backButton)
        
        setupLayout()
    }
    
    private func setupLayout() {
        backButton.snp.makeConstraints { make in
            make.top.equalTo(self.safeAreaLayoutGuide.snp.top).offset(10)
            make.left.equalToSuperview().offset(10)
            make.width.height.equalTo(30)
        }
        
        titleLabel.snp.makeConstraints { make in
            make.top.equalTo(backButton.snp.bottom).offset(20)
            make.centerX.equalToSuperview()
        }
        
        naverButton.snp.makeConstraints { make in
            make.top.equalTo(titleLabel.snp.bottom).offset(50)
            make.left.equalToSuperview().offset(30)
            make.right.equalToSuperview().offset(-30)
            make.height.equalTo(50)
        }
        
        kakaoButton.snp.makeConstraints { make in
            make.top.equalTo(naverButton.snp.bottom).offset(20)
            make.left.equalTo(naverButton)
            make.right.equalTo(naverButton)
            make.height.equalTo(50)
        }
        
        publicAuthButton.snp.makeConstraints { make in
            make.top.equalTo(kakaoButton.snp.bottom).offset(20)
            make.left.equalTo(naverButton)
            make.right.equalTo(naverButton)
            make.height.equalTo(50)
        }
    }
}
