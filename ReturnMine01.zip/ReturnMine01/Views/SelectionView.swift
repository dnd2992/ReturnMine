import UIKit
import SnapKit

class SelectionView: UIView {

    let titleLabel: UILabel = {
        let label = UILabel()
        label.text = "안녕하세요\n'[Name]' 님,\n무엇을 도와드릴까요?"
        label.font = UIFont.boldSystemFont(ofSize: 28)
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()
    
    let findLostItemButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("분실물 찾기", for: .normal)
        button.backgroundColor = .systemBlue
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 10
        return button
    }()
    
    let registerFoundItemButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("습득물 등록하기", for: .normal)
        button.backgroundColor = .brown
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 10
        return button
    }()
    
    let lost112Button: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("로스트 112", for: .normal)
        button.backgroundColor = .gray
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 10
        return button
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
        setupLayout()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupView() {
        backgroundColor = .white
        
        addSubview(titleLabel)
        addSubview(findLostItemButton)
        addSubview(registerFoundItemButton)
        addSubview(lost112Button)
    }

    private func setupLayout() {
        titleLabel.snp.makeConstraints { make in
            make.top.equalTo(safeAreaLayoutGuide).offset(50)
            make.centerX.equalToSuperview()
        }
        
        findLostItemButton.snp.makeConstraints { make in
            make.top.equalTo(titleLabel.snp.bottom).offset(70)
            make.left.equalToSuperview().offset(20)
            make.right.equalToSuperview().offset(-20)
            make.height.equalTo(50)
        }
        
        registerFoundItemButton.snp.makeConstraints { make in
            make.top.equalTo(findLostItemButton.snp.bottom).offset(40)
            make.left.equalTo(findLostItemButton)
            make.right.equalTo(findLostItemButton)
            make.height.equalTo(50)
        }
        
        lost112Button.snp.makeConstraints { make in
            make.top.equalTo(registerFoundItemButton.snp.bottom).offset(40)
            make.left.equalTo(registerFoundItemButton)
            make.right.equalTo(registerFoundItemButton)
            make.height.equalTo(50)
        }
    }
}
